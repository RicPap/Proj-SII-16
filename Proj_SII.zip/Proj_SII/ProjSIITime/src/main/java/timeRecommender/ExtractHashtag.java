package timeRecommender;

import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ExtractHashtag {

	public static void main(String[] args) throws IOException {
		FileReader f = new FileReader("/Users/blacksabber/DESKTOP/MySII/ProjSIITime/dataset.csv");
		Scanner br = new Scanner(f);
		Pattern singleLine = Pattern.compile("(?<=£§\"[0-9]{4}-[0-9]{2}-[0-9]{2}\"\n)");
		Pattern hashTags = Pattern.compile("#([A-Z]*[a-z]*[0-9]*)*");
		br.useDelimiter(singleLine);
		FileWriter w;
		w = new FileWriter("/Users/blacksabber/DESKTOP/MySII/ProjSIITime/userToHashtag.csv");
		BufferedWriter bw = new BufferedWriter (w);
		String sRead;
		while(br.hasNext()) {
			//System.out.println("Entro");
			sRead = br.next();
			String[] splitter = sRead.split("\"£§\"");
			String sDate = splitter[3];
			sDate = sDate.substring(0,sDate.length()-1);
			int date = convertDate(sDate);
			String content = splitter[2];
			Matcher findHashtag = hashTags.matcher(content);
			while(findHashtag.find()) {
				//System.out.println("dentro");
				String hashTag = findHashtag.group().toString().toLowerCase().substring(1);
				bw.write(splitter[0].substring(1)+","+hashTag+","+date+"\n");
			}
		}
		System.out.println("Sono uscito dal ciclo");
		bw.flush();
		br.close();
		bw.close();

	}

	// ricavo la data come il numero di giorni a partire dal 14-05-12 da stringhe del tipo "2012-05-15"
	private static int convertDate(String sDate) {
		try {
		String startDate = "2012-05-14";
		String format = "yyyy-MM-dd";
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		Date dateObj1 = sdf.parse(sDate);
		Date dateObj2 = sdf.parse(startDate);
		long diff = dateObj1.getTime() - dateObj2.getTime();
		return (int)(diff/(24* 1000 * 60 * 60)); //Math.round((float)diff / (24* 1000 * 60 * 60))
		}
		catch(Exception e) {
			return 999; // Debug porpuse
		}
	}
}