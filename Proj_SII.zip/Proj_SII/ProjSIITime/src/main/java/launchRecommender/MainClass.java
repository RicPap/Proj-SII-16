package launchRecommender;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import net.librec.conf.Configuration;
import net.librec.data.DataModel;
import net.librec.data.model.TextDataModel;
import net.librec.eval.RecommenderEvaluator;
import net.librec.eval.rating.RMSEEvaluator;
import net.librec.filter.GenericRecommendedFilter;
import net.librec.recommender.Recommender;
import net.librec.recommender.RecommenderContext;
import net.librec.recommender.item.RecommendedItem;
import net.librec.similarity.PCCSimilarity;
import net.librec.similarity.RecommenderSimilarity;

public class MainClass {
	public static void main(String[] args) throws Exception {

		// build data model
		Configuration conf = new Configuration();
		conf.set("dfs.data.dir", "/Users/blacksabber/DESKTOP/MySII/ProjSIITime");
		conf.set("dfs.result.dir", "/Users/blacksabber/DESKTOP/MySII/ProjSIITime/twitterOut");
		conf.set("data.input.path", "/twitterIN");
		conf.set("data.column.format", "UIRT");
		conf.set("data.model.splitter", "testset");
		conf.set("data.testset.path", "twitterIN/testSet.csv");
		conf.set("data.model.format", "text");
		conf.set("rec.random.isranking", "false");
		conf.set("rec.random.seed", "1");
		conf.set("rec.similarity.class", "pcc");
		
		DataModel dataModel = new TextDataModel(conf);
		dataModel.buildDataModel();
		
		// build recommender context
		RecommenderContext context = new RecommenderContext(conf, dataModel);

		// build similarity
		conf.set("rec.recommender.similarities" ,"item");
		RecommenderSimilarity similarity = new PCCSimilarity();
		similarity.buildSimilarityMatrix(dataModel);
		context.setSimilarity(similarity);

		// build recommender
		conf.set("rec.neighbors.knn.number", "10");
        Recommender recommender = new MyRecommender();
        recommender.setContext(context);

		// run recommender algorithm
		recommender.recommend(context);

		// evaluate the recommended result
		RecommenderEvaluator evaluator = new RMSEEvaluator();
		System.out.println("RMSE:" + recommender.evaluate(evaluator));

		// set id list of filter
		List<String> userIdList = new ArrayList<>();
		userIdList.add("100258169");
		//printRecommendedUsers(userIdList,similarities,10);

		// filter the recommended result
		List<RecommendedItem> recommendedItemList = recommender.getRecommendedList();
		GenericRecommendedFilter filter = new GenericRecommendedFilter();
		filter.setUserIdList(userIdList);
		recommendedItemList = filter.filter(recommendedItemList);

		// print filter result
		int count = 0;
		Map<Double,List<String>> rate2item = new HashMap<>();
		System.out.print("user: " + userIdList.get(0)+"\t[");
		for (RecommendedItem recommendedItem : recommendedItemList) {
			if(rate2item.containsKey(recommendedItem.getValue()))
				rate2item.get(recommendedItem.getValue()).add(recommendedItem.getItemId());
			else
			{
				List<String> newL = new LinkedList<>();
				newL.add(recommendedItem.getItemId());
				rate2item.put(recommendedItem.getValue(), newL);
			}
		}
		for (Double rating : rate2item.keySet()) {
			List<String> items = rate2item.get(rating);
			for(String item : items) {
			System.out.print(item + ", ");
			//top 5
			if(count == 5) break;
			count++;
			}
			if(count == 5) break;
		}
		System.out.println("]\n");
	}
}