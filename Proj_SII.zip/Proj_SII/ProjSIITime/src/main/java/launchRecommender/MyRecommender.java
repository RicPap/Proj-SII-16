package launchRecommender;

import net.librec.annotation.ModelData;
import net.librec.common.LibrecException;
import net.librec.math.structure.DenseVector;
import net.librec.math.structure.SparseVector;
import net.librec.math.structure.SymmMatrix;
import net.librec.math.structure.VectorEntry;
import net.librec.recommender.AbstractRecommender;
import net.librec.util.Lists;

import java.util.*;
import java.util.Map.Entry;

@ModelData({"isRanking", "knn", "itemMeans", "trainMatrix", "similarityMatrix"})
public class MyRecommender extends AbstractRecommender {
    private int knn;
    private DenseVector itemMeans;
    private SymmMatrix similarityMatrix;
    private List<Map.Entry<Integer, Double>>[] itemSimilarityList;
    private int currentUserIdx = -1;
    private Set<Integer> currentItemIdxSet;

    @Override
    protected void setup() throws LibrecException {
        super.setup();
        knn = conf.getInt("rec.neighbors.knn.number",10);
        similarityMatrix = context.getSimilarity().getSimilarityMatrix();
    }

    @Override
    protected void trainModel() throws LibrecException {
        itemMeans = new DenseVector(numItems);
        int numRates = trainMatrix.size();
        double globalMean = trainMatrix.sum() / numRates;
        for (int  itemIdx = 0; itemIdx < numItems; itemIdx++) {
            SparseVector userRatingVector = trainMatrix.column(itemIdx);
            itemMeans.set(itemIdx, userRatingVector.getCount() > 0 ? userRatingVector.mean() : globalMean);
        }
    }

    public double predict(int userIdx, int itemIdx) throws LibrecException {
        //create itemSimilarityList if not exists
        if (!(null != itemSimilarityList && itemSimilarityList.length > 0)) {
            createItemSimilarityList();
        }

        if (currentUserIdx != userIdx) {
            currentItemIdxSet = trainMatrix.getColumnsSet(userIdx);
            currentUserIdx = userIdx;
        }

        // find a number of similar items
        List<Map.Entry<Integer, Double>> nns = new ArrayList<>();
        List<Map.Entry<Integer, Double>> simList = itemSimilarityList[itemIdx];

        int count = 0;
        for (Map.Entry<Integer, Double> itemRatingEntry : simList) {
            int similarItemIdx = itemRatingEntry.getKey();
            if (!currentItemIdxSet.contains(similarItemIdx)) {
                continue;
            }
            double sim = itemRatingEntry.getValue();
            if (sim > 0) {
                nns.add(itemRatingEntry);
                count++;
            }
            if (count == knn) {
                break;
            }
        }
        if (nns.size() == 0) {
            return isRanking ? 0 : globalMean;
        }
        else {
            double sum = 0, ws = 0;
            for (Entry<Integer, Double> itemRatingEntry : nns) {
                int similarItemIdx = itemRatingEntry.getKey();
                double sim = itemRatingEntry.getValue();
                double rate = trainMatrix.get(userIdx, similarItemIdx);
                double discount = getDiscountFactor(similarItemIdx,userIdx,rate);
                sum += sim * rate * discount;
                ws += Math.abs(sim) * discount;
            }
            return sum / ws;
        }
    }

    private double getDiscountFactor(int similarItemIdx,int userIdx,double rate) {
    	List<Map.Entry<Integer, Double>> nns = new ArrayList<>();
        List<Map.Entry<Integer, Double>> simList = itemSimilarityList[similarItemIdx];
        int count = 0;
        double sumRate = 0, up = 0, down = 0;
        for (Map.Entry<Integer, Double> itemRatingEntry : simList) {
            double sim = itemRatingEntry.getValue();
            if (sim > 0) {
                nns.add(itemRatingEntry);
                count++;
            }
            if (count == knn) {
                break;
            }
        }
        for (Entry<Integer, Double> itemRatingEntry : nns) {
            int simItemIdx = itemRatingEntry.getKey();
            double simItemRate = trainMatrix.get(userIdx, simItemIdx);
            sumRate += simItemRate;
        }
        up = Math.abs((sumRate/nns.size())-rate);
        down = 5d;
		return Math.pow(1-(up/down), 0.4);
	}

	/**
     * Create itemSimilarityList.
     */
    @SuppressWarnings("unchecked")
	public void createItemSimilarityList() {
        itemSimilarityList = new ArrayList[numItems];
        for (int itemIdx = 0; itemIdx < numItems; ++itemIdx) {
            SparseVector similarityVector = similarityMatrix.row(itemIdx);
            itemSimilarityList[itemIdx] = new ArrayList<>(similarityVector.size());
            Iterator<VectorEntry> simItr = similarityVector.iterator();
            while (simItr.hasNext()) {
                VectorEntry simVectorEntry = simItr.next();
                itemSimilarityList[itemIdx].add(new AbstractMap.SimpleImmutableEntry<>(simVectorEntry.index(), simVectorEntry.get()));
            }
            Lists.sortList(itemSimilarityList[itemIdx], true);
        }
    }
}