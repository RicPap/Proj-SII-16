package launchRecommender;

import net.librec.annotation.ModelData;
import net.librec.common.LibrecException;
import net.librec.math.structure.DenseVector;
import net.librec.math.structure.SparseMatrix;
import net.librec.math.structure.SparseVector;
import net.librec.math.structure.SymmMatrix;
import net.librec.math.structure.VectorEntry;
import net.librec.recommender.AbstractRecommender;
import net.librec.util.Lists;

import java.util.*;
import java.util.Map.Entry;

@ModelData({"isRanking", "knn", "itemMeans", "trainMatrix", "similarityMatrix", "timeMatrix"})
public class TimeWeightRec extends AbstractRecommender {
    private int knn;
    private DenseVector itemMeans;
    private static SparseMatrix timeMatrix;
    private SymmMatrix similarityMatrix;
    private List<Map.Entry<Integer, Double>>[] itemSimilarityList;
    private int currentUserIdx = -1;
    private Set<Integer> currentItemIdxSet;
    int time;

    @Override
    protected void setup() throws LibrecException {
        super.setup();
        knn = conf.getInt("rec.neighbors.knn.number",10);
        Scanner scan = new Scanner(System.in);
        System.out.println("Inserire tempo");
        time = scan.nextInt();
        scan.close();
        timeMatrix = (SparseMatrix) getDataModel().getDatetimeDataSet();
        if(timeMatrix==null)
        	System.out.println("NOOOOOOO");
        similarityMatrix = context.getSimilarity().getSimilarityMatrix();
    }

    @Override
    protected void trainModel() throws LibrecException {
        itemMeans = new DenseVector(numItems);
        int numRates = trainMatrix.size();
        double globalMean = trainMatrix.sum() / numRates;
        for (int  itemIdx = 0; itemIdx < numItems; itemIdx++) {
            SparseVector userRatingVector = trainMatrix.column(itemIdx);
            itemMeans.set(itemIdx, userRatingVector.getCount() > 0 ? userRatingVector.mean() : globalMean);
        }
    }

    public double predict(int userIdx, int itemIdx) throws LibrecException {
        //create itemSimilarityList if not exists
        if (!(null != itemSimilarityList && itemSimilarityList.length > 0)) {
            createItemSimilarityList();
        }

        if (currentUserIdx != userIdx) {
            currentItemIdxSet = trainMatrix.getColumnsSet(userIdx);
            currentUserIdx = userIdx;
        }

        // find a number of similar items
        List<Map.Entry<Integer, Double>> nns = new ArrayList<>();
        List<Map.Entry<Integer, Double>> simList = itemSimilarityList[itemIdx];
        
        int count = 0;
        for (Map.Entry<Integer, Double> itemRatingEntry : simList) {
            int similarItemIdx = itemRatingEntry.getKey();
            if (!currentItemIdxSet.contains(similarItemIdx)) {
                continue;
            }

            double sim = itemRatingEntry.getValue();

            if (sim > 0) {
                nns.add(itemRatingEntry);
                count++;
            }
            if (count == knn) {
                break;
            }
        }
        if (nns.size() == 0) {
            return globalMean;
        }
        
        else {
            double sum = 0, ws = 0, tweight = 0;
            for (Entry<Integer, Double> itemRatingEntry : nns) {
                int similarItemIdx = itemRatingEntry.getKey();
                double sim = itemRatingEntry.getValue();
                double rate = trainMatrix.get(userIdx, similarItemIdx);
                tweight = getTimeWeight(time,userIdx,similarItemIdx);
                sum += (tweight*sim) * (rate - itemMeans.get(similarItemIdx));
                ws += tweight*Math.abs(sim);
            }
            return itemMeans.get(itemIdx) + sum / ws;
        }
    }

	private double getTimeWeight(int time,int user,int item) {
		double curTime = timeMatrix.get(item, user);
		double a = (0.9-1)*(time-curTime);
		return Math.pow(Math.E,a);
	}

	/**
     * Create itemSimilarityList.
     */
    @SuppressWarnings("unchecked")
	public void createItemSimilarityList() {
        itemSimilarityList = new ArrayList[numItems];
        for (int itemIdx = 0; itemIdx < numItems; ++itemIdx) {
            SparseVector similarityVector = similarityMatrix.row(itemIdx);
            itemSimilarityList[itemIdx] = new ArrayList<>(similarityVector.size());
            Iterator<VectorEntry> simItr = similarityVector.iterator();
            while (simItr.hasNext()) {
                VectorEntry simVectorEntry = simItr.next();
                itemSimilarityList[itemIdx].add(new AbstractMap.SimpleImmutableEntry<>(simVectorEntry.index(), simVectorEntry.get()));
            }
            Lists.sortList(itemSimilarityList[itemIdx], true);
        }
    }
}